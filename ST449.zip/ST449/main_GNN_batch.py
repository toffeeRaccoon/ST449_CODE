import os
# CAN FORGET
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = "2"

import torch
import numpy as np
from datetime import datetime
import argparse
from utils import _logger, set_requires_grad
# dataloader_GNN.py all 
from dataloader.dataloader_GNN import data_generator
# trainer_GNN.py all
from trainer.trainer_GNN import Trainer, model_evaluate, draw_tsne

# seems no use
from models.TC_GNN import TC

from utils import _calc_metrics, copy_Files
from models.model_GNN_CNN import Base_model, SpatialHeteroModel

# Args selections
start_time = datetime.now()


parser = argparse.ArgumentParser()

######################## Model parameters ########################
home_dir = os.getcwd()
parser.add_argument('--experiment_description', default='GCC', type=str,
                    help='Experiment Description')
parser.add_argument('--run_description', default='run1', type=str,
                    help='Experiment Description')
parser.add_argument('--seed', default=2, type=int,
                    help='seed value')
parser.add_argument('--training_mode', default='train_linear', type=str)
parser.add_argument('--selected_dataset', default='HAR', type=str)
parser.add_argument('--logs_save_dir', default='/home/shaoqi/code/TS-GAC-main/experiments_logs', type=str,
                    help='saving directory')
parser.add_argument('--device', default='cuda', type=str,
                    help='cpu or cuda')
parser.add_argument('--home_path', default=home_dir, type=str,
                    help='Project home directory')
parser.add_argument('--nmb_prototype_spatial', default=6, type=int,
                    help='cluster for spatial')
parser.add_argument('--nmb_prototype_temporal', default=6, type=int,
                    help='cluster for temporal')
parser.add_argument('--output_size', default=64, type=int,
                    help='feature dim of embedding for graph constrasive')
parser.add_argument('--temp', default=0.5, type=int,
                    help='constrasive loss temp')
parser.add_argument('--tnse', default=True, type=bool,
                    help='tnse')

def main(configs, args, lambda1, lambda2, lambda3,num_remain_aug1, num_remain_aug2):
    device = torch.device(args.device)
    experiment_description = args.experiment_description

    method = 'GCC'
    training_mode = args.training_mode
    run_description = args.run_description

    logs_save_dir = args.logs_save_dir
    os.makedirs(logs_save_dir, exist_ok=True)

    # ##### fix random seeds for reproducibility ########
    SEED = args.seed
    torch.manual_seed(SEED)
    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = False
    np.random.seed(SEED)
    #####################################################
    # + args.selected_dataset
    experiment_log_dir = os.path.join(logs_save_dir, experiment_description, run_description, training_mode + args.selected_dataset + f"_seed_{SEED}" )
    os.makedirs(experiment_log_dir, exist_ok=True)

    # loop through domains
    counter = 0
    src_counter = 0


    # Logging
    log_file_name = os.path.join(experiment_log_dir, f"logs_{datetime.now().strftime('%d_%m_%Y_%H_%M_%S')}.log")
    logger = _logger(log_file_name)
    logger.debug("=" * 45)
    logger.debug(f'Dataset: {data_type}')
    logger.debug(f'Method:  {method}')
    logger.debug(f'Mode:    {training_mode}')
    logger.debug("=" * 45)
    
    # data path need to be changed  f"/home/shaoqi/code/TS-GAC-main/GCC/data/{data_type}"
    data_path = f"/TS-GAC-main/GCC/data/{data_type}"
    train_dl, test_dl = data_generator(data_path, configs, args)

    logger.debug("Data loaded ...")

    # Load Model
    model = Base_model(configs, args).to(device)
    #temporal_contr_model = TC(configs, args, device).to(device)
    prototype_loss_sptial = SpatialHeteroModel(configs.final_out_channels, args.nmb_prototype_spatial, configs.batch_size).to(device)
    prototype_loss_temporal = SpatialHeteroModel(configs.final_out_channels, args.nmb_prototype_temporal, configs.batch_size).to(device)


    if training_mode == "train_linear" or "tl" in training_mode:
        load_from = os.path.join(os.path.join(logs_save_dir, experiment_description, run_description, f"self_supervisedHAR_seed_{SEED}", "saved_models"))
        chkpoint = torch.load(os.path.join(load_from, "ckp_last.pt"), map_location=device)
        pretrained_dict = chkpoint["model_state_dict"]
        model_dict = model.state_dict()

        # 1. filter out unnecessary keys
        pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict}

        # delete these parameters (Ex: the linear layer at the end)
        del_list = ['logits']
        pretrained_dict_copy = pretrained_dict.copy()
        for i in pretrained_dict_copy.keys():
            for j in del_list:
                if j in i:
                    del pretrained_dict[i]

        model_dict.update(pretrained_dict)
        model.load_state_dict(model_dict)
        set_requires_grad(model, pretrained_dict, requires_grad=False)  # Freeze everything except last layer.


    model_optimizer = torch.optim.Adam(model.parameters(), lr=configs.lr, betas=(configs.beta1, configs.beta2), weight_decay=3e-4)
    prototype_loss_spatial_optimizer = torch.optim.Adam(prototype_loss_sptial.parameters(), lr=configs.lr, betas=(configs.beta1, configs.beta2), weight_decay=3e-4)
    prototype_loss_temporal_optimizer = torch.optim.Adam(prototype_loss_temporal.parameters(), lr=configs.lr, betas=(configs.beta1, configs.beta2), weight_decay=3e-4)

    if training_mode == "self_supervised":  # to do it only once
        copy_Files(os.path.join(logs_save_dir, experiment_description, run_description), data_type)

    if training_mode == "train_linear" :
        if args.tnse:
            draw_tsne(model, train_dl, device)

    # Trainer
    Trainer(model, prototype_loss_sptial, prototype_loss_temporal, model_optimizer, prototype_loss_spatial_optimizer, prototype_loss_temporal_optimizer, train_dl, test_dl, device, logger, configs, experiment_log_dir, training_mode,
            lambda1, lambda2, lambda3,num_remain_aug1, num_remain_aug2, args)

    if training_mode != "self_supervised":
        # Testing
        outs = model_evaluate(model, test_dl, device, training_mode)
        total_loss, total_acc, pred_labels, true_labels = outs
        _calc_metrics(pred_labels, true_labels, experiment_log_dir, args.home_path)

    logger.debug(f"Training time is : {datetime.now()-start_time}")


if __name__ == '__main__':

    # dataset_UEA = ['HAR', 'ISRUC', 'ArticularyWordRecognition', 'FingerMovements','SpokenArabicDigits']
    dataset_UEA = ['HAR', 'ArticularyWordRecognition', 'FingerMovements','SpokenArabicDigits']

    default_lambda1 = 1
    default_lambda2 = 0.5
    default_lambda3 = 0.5

    args = parser.parse_args()
    
    # change dataset
    args.selected_dataset = 'HAR'
    data_type = args.selected_dataset
    exec(f'from config_files.{data_type}_Configs import Config as Configs')
    configs = Configs()

    num_remain_aug1 = 7  # 8 7
    num_remain_aug2 = 4  # 2
    for j in range(1):

        args.training_mode = 'self_supervised'
        main(configs, args, default_lambda1, default_lambda2, default_lambda3, num_remain_aug1, num_remain_aug2)
        args.training_mode = 'train_linear'
        main(configs, args, default_lambda1, default_lambda2, default_lambda3, num_remain_aug1, num_remain_aug2)